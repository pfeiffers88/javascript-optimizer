<?php
// Config for backend and frontend
define ('pfeiffersMS_PLUGIN_VERSION', '1.3');

define ('pfeiffersMS_OPTION', 'pfeiffersms_options');
define ('pfeiffersMS_OPTION_NOTICE', 'pfeiffersms_notice');
define ('pfeiffersMS_OPTION_VERSION', 'pfeiffersms_plugin_version');
define ('pfeiffersMS_PLUGIN_DIR_NAME', 'optimize-javascript');
define ('pfeiffersMS_PLUGIN_FILE_NAME', 'pfeiffers-merge-scripts.php');
define ('pfeiffersMS_DS', DIRECTORY_SEPARATOR);
define ('pfeiffersMS_PLUGIN_PATH', WP_PLUGIN_DIR . pfeiffersMS_DS . pfeiffersMS_PLUGIN_DIR_NAME);
define ('pfeiffersMS_PLUGIN_URL', WP_PLUGIN_URL . '/' . pfeiffersMS_PLUGIN_DIR_NAME);
?>