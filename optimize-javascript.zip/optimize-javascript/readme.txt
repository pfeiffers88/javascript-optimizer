=== Minify Javascript ===
Contributors: peterpfeiffer
Tags: minify, merge, js, js minifcation, js minify, js optimize, js optimizer, minifer, minification, minify js, optimize, optimizer, javascript minification, javascript, javascript minify, javascript optimize, javascript optimizer, minify javascript, 
Requires at least: 3.6
Tested up to: 4.7
Stable tag: 1.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Minify and Optimize your Javascript by clicking one button and place it in the footer or header.

== Description ==

Minify and Optimize your Javascript by clicking one button. All you have to do is go to Settings and click Javascript Minify. Activating the plugin there will minify and optimize your Javascript. No settings required, just click one button.

So anything you can do to speed up the load time of your site should be worth investigating, right? One such thing is “minifying” the Javascript files that are used in part to build your site. As is typically the case, there is a plugin available that can do the job for you – Suprise: It's this one! Code from this plugin is forked from aph merge scripts a really great plugin. You can find it by searching for it here on wordpress.org in the plugin search. Also full copyright to JShrink and YUIcompressor, which is used in this plugin.

1. Upload the zip file and unzip it in the /wp-content/plugins/ directory.
2. Activate the plugin through the Plugins menu in WordPress
3. Go to Settings and then click Javascript Minify and enable the options you want.


== Installation ==

1. Upload the zip file and unzip it in the /wp-content/plugins/ directory.
2. Activate the plugin through the Plugins menu in WordPress
3. Go to Settings and then click Javascript Minify and enable the options you want.